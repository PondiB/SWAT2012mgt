## Some infix paste functions ---------------------------------------------
'%_%' <- function(a, b) paste(a, b, sep = "_")
'%.%' <- function(a, b) paste(a, b, sep = ".")
'%/%' <- function(a, b) paste(a, b, sep = "/")
'%|%' <- function(a, b) paste(a, b, sep = "    | ")
